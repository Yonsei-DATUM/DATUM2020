#1. Load packages and Data ----
library(tidyverse)
library(magrittr)
library(caret)
library(e1071)
library(ggplot2)
data.train= read.csv("스트레스의과학과적응의삶-train.csv") #dim 721 11
data.test = read.csv("스트레스의과학과적응의삶-test.csv") #dim 102 11
data.test$success.fail %>% table() #2020-1: success 70, fail 32

#2. Summarize Data & Cleaning Data ----

#A. Training data: 2016-1 ~ 2020-1 ----
dim(data.train) #dim 1598 11
data.train %>% glimpse()

#took.cred_total.cred & year features might be redundant; check correlation

gg1 = ggplot(data.train, aes(x= year, y= took.cred_total.cred, group = year)) + 
  geom_boxplot()+
  ggtitle("Relationship between 'year' and 'took.cred_total.cred'") +
  xlim( "1" ,"2","3", "4","5") + 
  theme_minimal()

gg1

saveRDS(gg1, "stress_eda1.rds")

gg2 = ggplot(data.train, aes(x= year, y= took.cred_total.cred, group = year, col = success.fail)) + 
  geom_jitter()+
  ggtitle("Relationship between 'year' and 'took.cred_total.cred'") +
  xlim( "1" ,"2","3", "4","5") + 
  theme_minimal() + 
  scale_color_manual(values = c("black", "red"))

gg2

saveRDS(gg2, "stress_eda2.rds")

str(data.train) #select(-c(rank, major, app.grad, X, year))
sapply(data.train,class) #change XO to ordered factor

##2.1 Subset data
data.train = data.train %>% select(-c( ï..rank, major, app.grad, X, year))
##2.2 Change data type of target data
data.train %<>%
  mutate(`success.fail`=
           replace(`success.fail`, `success.fail` == "O", "success")) #성공

data.train %<>%
  mutate(`success.fail`=
           replace(`success.fail`, `success.fail`== "X", "fail")) #실패

data.train$success.fail %<>% as.factor %>% ordered()
data.train$success.fail %>% class
##2.3 Check changed data type
data.train %>% glimpse()
data.train %>% sapply(., class)
data.train$first.take %<>% as.factor %>% ordered()
##2.4 Descriptive Statistics
summary(data.train) # data ok, first.take: N 107, Y 2235, success.fail: f 693, s 1648
data.train %>% Hmisc::hist.data.frame()
##2.5 final check, finalize training dataset
data.train %>% sapply(., class)

train = data.train

#B. Testing data: 2020-2 ----
dim(data.test) #dim: 225, 11
data.test %>% glimpse()
str(data.test)
##2.1 Subset data
data.test = data.test %>% select(-c( ï..rank, major, app.grad, X, year))
##2.2 Change data type of target data
data.test %<>%
  mutate(`success.fail`=
           replace(`success.fail`, `success.fail` == "O", "success")) #성공

data.test %<>%
  mutate(`success.fail`=
           replace(`success.fail`, `success.fail`== "X", "fail")) #실패

data.test$success.fail %<>% as.factor %>% ordered()
data.test$success.fail %>% class
##2.3 Check changed data type
data.test %>% glimpse()
data.test %>% sapply(., class)
data.test$first.take %<>% as.factor %>% ordered()
##2.4 Descriptive Statistics
summary(data.test) # data ok, first.take: N 20, Y 205, success.fail: f 27, s 198
data.test %>% Hmisc::hist.data.frame() #mostly num.courses, year = 2

##2.5 final check, compare with training data, finalize datatest
data.test %>% sapply(., class)
str(train)
str(data.test) #same data type/ levels
test = data.test

rm(data.raw)

##2.7 Feature Extraction
#feature extract
target.label = "success.fail"

features.label = train %>% 
  select(-target.label) %>% 
  names() %T>% print

features = train %>% 
  select(features.label)

formula = features %>%
  names() %>% 
  paste(., collapse = " + ") %>% 
  paste(target.label, "~ ", .) %>% 
  as.formula(env = .GlobalEnv) %T>% print

formula

#3. Evaluate between different Algorithms ----
##3.1 Test Harness
trainControl = trainControl(method = "repeatedcv", 
                            number = 9, 
                            repeats = 3,
                            classProbs = T,
                            search = "random")
metric = "Accuracy"
##3.2 Build Models
seed = 323
##3.2.1 simple linear vs simple non-linear
#lda
set.seed(seed)
fit.lda = train(formula, 
                data = train, 
                method = "lda", 
                metric = metric, trControl = trainControl,
                preProc = c("scale", "center"))
#cart (decision tree)
set.seed(seed)
fit.cart = train(formula, 
                 data = train, 
                 method = "rpart", 
                 metric = metric, 
                 trControl = trainControl,
                 preProc = c("scale", "center"))
#knn
set.seed(seed)
fit.knn = train(formula, 
                data = train, 
                method = "knn", 
                metric = metric, 
                trControl = trainControl,
                preProc = c("scale", "center"))
# invalid: warnings of too many ties - > see in Kappa
##3.2.2 complex non-linear
#svm
set.seed(seed)
fit.svm = train(formula, 
                data = train, 
                method = "svmRadial", 
                metric = metric, 
                trControl = trainControl,
                preProc = c("scale", "center"))
#random forest
set.seed(seed)
fit.rf = train(formula, 
               data = train, 
               method = "rf", 
               metric = metric, 
               trControl = trainControl,
               preProc = c("scale", "center"))


#4. Select Best Algorithm ----
##4.1 Summarize accuracy of models
results = resamples(list(lda = fit.lda, cart = fit.cart, knn = fit.knn, svm = fit.svm, rf = fit.rf))
summary(results) #svm is the best fit, although mean Kappa score is around 55, a bit low
dot.plot=dotplot(results) %T>% print()#CI of 95%

saveRDS(dot.plot, "algocomparisons_stress.rds")

print(fit.svm)
#5. Making Predictions by tuning algorithms----
#A. SVM: not-tuned ----
pr.1 = predict(fit.svm,test)
#5.A.1 Checking confusion matrix: fit.svm
confusionMatrix(pr.1, test$success.fail) #ok model- Accuracy : 0.8725, Kappa : 0.7293 

#B. SVM: tuned ----
#5.B.1 Tuning Kernels
# set.seed(seed)
# result1 = tune.svm(formula, data = train, scale = F, gamma = 2^(-5:0), cost = 2^(0:4), kernel = "radial")
# set.seed(seed)
# result2 = tune.svm(formula, data = train, cost = 2^(0:4), kernel = "linear")
# set.seed(seed)
# result3 = tune.svm(formula, data = train, cost = 2^(0:4), degree = 2:4, kernel = "polynomial")
# set.seed(seed)
# result4 = tune.svm(formula, data = train, gamma = 2^(-5:0), cost = 2^(0:4), kernel = "sigmoid")

#5.B.2 Finding Best Params
# result1$best.parameters
# result2$best.parameters
# result3$best.parameters
# result4$best.parameters

fit.svm.1=svm(formula, data = train, scale = F, gamma = 0.03125, cost =16, kernel = "radial", trControl = trainControl)
fit.svm.2=svm(formula, data = train, cost = 1, kernel = "linear", trControl = trainControl)
fit.svm.3=svm(formula, data = train, cost = 8, degree = 2, kernel = "polynomial", trControl = trainControl)
fit.svm.4=svm(formula, data = train, gamma = 0.03125, cost = 4, kernel = "sigmoid", trControl = trainControl)

#5.B.3 Compare four tuned models of svm
#need to add another level to the factor first.take
test$first.take = factor(test$first.take, levels = c(levels(test$first.take), "N"))
test$first.take %>% table()
str(test)
str(train)
#relevel test$first.take
test$first.take = ordered(test$first.take, levels = c("N", "Y"))

#5.B.4 Predicting Accuracy
svm1_p = predict(fit.svm.1, test) 
# svm1_p %>% table
svm2_p = predict(fit.svm.2, test) 
# svm2_p %>% table
svm3_p = predict(fit.svm.3, test) 
# svm3_p %>% table
svm4_p = predict(fit.svm.4, test)
# svm4_p %>% table()
confusionMatrix(svm1_p, test$success.fail) 
confusionMatrix(svm2_p, test$success.fail) 
confusionMatrix(svm3_p, test$success.fail) #best svm- Accuracy : 0.9412,  Kappa : 0.8679 
confusionMatrix(svm4_p, test$success.fail)

#5.B.5 Plotting confusion matrix plot: fit.svm.3
cm.svm = confusionMatrix(svm3_p, test$success.fail)
cm.svm.df = as.data.frame(cm.svm$table)
cm.svm.df_prop = as.data.frame(prop.table(cm.svm$table))
cm.svm.df$Perc = round(cm.svm.df_prop$Freq*100,0)
cm.svm_p = ggplot(data = cm.svm.df, aes(x = Prediction , y =  Reference, fill = Freq))+
  geom_tile() +
  geom_text(aes(label = paste("",Freq,"(",Perc,"%)")), color = 'black', size = 5) +
  theme_classic() +
  guides(fill=FALSE) +
  ggtitle("Support Vector Machine (tuned) Confusion Matrix: 2020-1") +
  scale_fill_gradient(low = "white", high = "#badb33") +
  geom_tile(color = "black", fill = "black", alpha = 0)

cm.svm_p
saveRDS(cm.svm_p, "svmcm_stress.rds")


#6.Compare best models: fit.cart vs fit.rf.1
# rm(list=ls())
# dev.off()
readRDS("svmcm_stress.rds") #fit.svm.3
# best model = fit.svm.3 (tuned svm)