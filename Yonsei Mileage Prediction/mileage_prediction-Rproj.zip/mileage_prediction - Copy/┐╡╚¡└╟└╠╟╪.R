#1. Load packages and Data ----
library(tidyverse)
library(magrittr)
library(caret)
library(rpart)
library(rpart.plot)
library(e1071)
library(ggplot2)
data.train= read.csv("영화의이해-train.csv") #dim 1598 11
data.test = read.csv("영화의이해-test.csv") #dim 225 11
data.test$success.fail %>% table() #2020-1: success 198, fail 54

#2. Summarize Data & Cleaning Data ----

#A. Training data: 2016-1 ~ 2020-1 ----
dim(data.train) #dim 1598 11
data.train %>% glimpse()

#took.cred_total.cred & year features might be redundant; check correlation

gg1 = ggplot(data.train, aes(x= year, y= took.cred_total.cred, group = year)) + 
  geom_boxplot()+
  ggtitle("Relationship between 'year' and 'took.cred_total.cred'") +
  xlim( "1" ,"2","3", "4","5") + 
  theme_minimal()

gg1

saveRDS(gg1, "undermv_eda1.rds")

gg2 = ggplot(data.train, aes(x= year, y= took.cred_total.cred, group = year, col = success.fail)) + 
  geom_jitter()+
  ggtitle("Relationship between 'year' and 'took.cred_total.cred'") +
  xlim( "1" ,"2","3", "4","5") + 
  theme_minimal() + 
  scale_color_manual(values = c("black", "red"))

gg2

saveRDS(gg2, "undermv_eda2.rds")

str(data.train) #select(-c(rank, major, app.grad, X, year))
sapply(data.train,class) #change XO to ordered factor
##2.1 Subset data
data.train = data.train %>% select(-c( ï..rank, major, app.grad, X, year))
##2.2 Change data type of target data
data.train %<>%
  mutate(`success.fail`=
           replace(`success.fail`, `success.fail` == "O", "success")) #성공

data.train %<>%
  mutate(`success.fail`=
           replace(`success.fail`, `success.fail`== "X", "fail")) #실패

data.train$success.fail %<>% as.factor %>% ordered()
data.train$success.fail %>% class
##2.3 Check changed data type
data.train %>% glimpse()
data.train %>% sapply(., class)
data.train$first.take %<>% as.factor %>% ordered()
##2.4 Descriptive Statistics
summary(data.train) # data ok, first.take: N 107, Y 2235, success.fail: f 693, s 1648
data.train %>% Hmisc::hist.data.frame()
##2.5 final check, finalize training dataset
data.train %>% sapply(., class)

train = data.train

#B. Testing data: 2020-2 ----
dim(data.test) #dim: 225, 11
data.test %>% glimpse()
str(data.test)
##2.1 Subset data
data.test = data.test %>% select(-c( ï..rank, major, app.grad, X, year))
##2.2 Change data type of target data
data.test %<>%
  mutate(`success.fail`=
           replace(`success.fail`, `success.fail` == "O", "success")) #성공

data.test %<>%
  mutate(`success.fail`=
           replace(`success.fail`, `success.fail`== "X", "fail")) #실패

data.test$success.fail %<>% as.factor %>% ordered()
data.test$success.fail %>% class
##2.3 Check changed data type
data.test %>% glimpse()
data.test %>% sapply(., class)
data.test$first.take %<>% as.factor %>% ordered()
##2.4 Descriptive Statistics
summary(data.test) # data ok, first.take: N 20, Y 205, success.fail: f 27, s 198
data.test %>% Hmisc::hist.data.frame() #mostly num.courses, year = 2

##2.5 final check, compare with training data, finalize datatest
data.test %>% sapply(., class)
str(train)
str(data.test) #same data type/ levels
test = data.test

rm(data.raw)

##2.7 Feature Extraction
#feature extract
target.label = "success.fail"

features.label = train %>% 
  select(-target.label) %>% 
  names() %T>% print

features = train %>% 
  select(features.label)

formula = features %>%
  names() %>% 
  paste(., collapse = " + ") %>% 
  paste(target.label, "~ ", .) %>% 
  as.formula(env = .GlobalEnv) %T>% print

formula

#3. Evaluate between different Algorithms ----
##3.1 Test Harness
trainControl = trainControl(method = "repeatedcv", 
                            number = 9, 
                            repeats = 3,
                            classProbs = T,
                            search = "random")
metric = "Accuracy"
##3.2 Build Models
seed = 323
##3.2.1 simple linear vs simple non-linear
#lda
set.seed(seed)
fit.lda = train(formula, 
                data = train, 
                method = "lda", 
                metric = metric, trControl = trainControl,
                preProc = c("scale", "center"))
#cart (decision tree)
set.seed(seed)
fit.cart = train(formula, 
                 data = train, 
                 method = "rpart", 
                 metric = metric, 
                 trControl = trainControl,
                 preProc = c("scale", "center"))
#knn
set.seed(seed)
fit.knn = train(formula, 
                data = train, 
                method = "knn", 
                metric = metric, 
                trControl = trainControl,
                preProc = c("scale", "center"))
# invalid: warnings of too many ties - > see in Kappa
##3.2.2 complex non-linear
#svm
set.seed(seed)
fit.svm = train(formula, 
                data = train, 
                method = "svmRadial", 
                metric = metric, 
                trControl = trainControl,
                preProc = c("scale", "center"))
#random forest
set.seed(seed)
fit.rf = train(formula, 
               data = train, 
               method = "rf", 
               metric = metric, 
               trControl = trainControl,
               preProc = c("scale", "center"))


#4. Select Best Algorithm ----
##4.1 Summarize accuracy of models
results = resamples(list(lda = fit.lda, cart = fit.cart, knn = fit.knn, svm = fit.svm, rf = fit.rf))
summary(results) #cart, rf, svm all good
dot.plot=dotplot(results) %T>% print()#CI of 95%

saveRDS(dot.plot, "algocomparisons_undermv.rds")

#5. Making Predictions by tuning algorithms----
#A. Decision Tree: not-tuned ----
pr.1 = predict(fit.cart,test)
#5.A.1 Checking confusion matrix: fit.cart
confusionMatrix(pr.1, test$success.fail) #good model- Accuracy : 0.9733, Kappa : 0.8737 
#5.A.2 Plotting Confusion Matrix for fit.cart
cm.cart = confusionMatrix(pr.1,test$success.fail) %T>% print
cm.cart.df = as.data.frame(cm.cart$table)
cm.cart.df_prop = as.data.frame(prop.table(cm.cart$table))
cm.cart.df$Perc = round(cm.cart.df_prop$Freq*100,0)
cm.cart_p = ggplot(data = cm.cart.df, aes(x = Prediction , y =  Reference, fill = Freq))+
  geom_tile() +
  geom_text(aes(label = paste("",Freq,"(",Perc,"%)")), color = 'black', size = 5) +
  theme_classic() +
  guides(fill=FALSE) +
  ggtitle("Decision Tree (not-tuned) Confusion Matrix: 2020-1") +
  scale_fill_gradient(low = "white", high = "#badb33") +
  geom_tile(color = "black", fill = "black", alpha = 0)

cm.cart_p
saveRDS(cm.cart_p, "decisiontreecm_undermv.rds")

#B. Tuned Decision Tree ----
set.seed(seed)
tree.cart = rpart(
  formula = formula,
  data = train
) %T>% print

tree.cart%>% printcp

# cp.best = tree.cart$cptable %>%
#   as.data.frame() %>%
#   filter(xerror == min(xerror)) %>%
#   .[1,"CP"] %T>% print 

# set.seed(seed)
# tree.cart.pruned = prune(tree.cart, cp = cp.best) %T>% print #don't prune; same
# tuning (pruning) failed at this point, in decision tree

#C. Random Forest (second best): not-tuned & tuned
#5.C.1 not-tuned
pr.2 = predict(fit.rf,test)
#5.C.2 Checking confusion matrix: fit.rf
confusionMatrix(pr.2, test$success.fail)
#5.C.3 tuned
set.seed(seed)
fit.rf.1 = train(formula, 
                 data = train, 
                 method = "rf", 
                 metric = metric, 
                 prProc = c("BoxCox"), 
                 tunelength = 15,
                 trControl = trainControl)

pr.3 = predict(fit.rf.1, test)
#5.C.4 Checking confusion matrix: fit.rf.1
cm.rf = confusionMatrix(pr.3,test$success.fail) %T>% print # Accuracy : 0.9733 Kappa : 0.8777 
cm.rf.df = as.data.frame(cm.rf$table)
cm.rf.df_prop = as.data.frame(prop.table(cm.rf$table))
cm.rf.df$Perc = round(cm.rf.df_prop$Freq*100,0)
cm.rf_p = ggplot(data = cm.rf.df, aes(x = Prediction , y =  Reference, fill = Freq))+
  geom_tile() +
  geom_text(aes(label = paste("",Freq,"(",Perc,"%)")), color = 'black', size = 5) +
  theme_classic() +
  guides(fill=FALSE) +
  ggtitle("Random Forest (tuned) Confusion Matrix: 2020-1") +
  scale_fill_gradient(low = "white", high = "#badb33") +
  geom_tile(color = "black", fill = "black", alpha = 0)

cm.rf_p

#5.C.5 Saving confusion matrix plot: fit.rf.1
saveRDS(cm.rf_p, "randomforestcm_undermv.rds")

#6.Compare best models: fit.cart vs fit.rf.1
# rm(list=ls())
# dev.off()
readRDS("decisiontreecm_undermv.rds") #fit.cart
readRDS("randomforestcm_undermv.rds") #fit.rf.1
# both dt and randomforest models similar