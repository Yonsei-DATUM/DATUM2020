#1. Load packages and Data ----
library(tidyverse)
library(magrittr)
library(caret)
library(e1071)
library(ggplot2)
data.raw = read.csv("진보와보수.csv")
data.raw %>% tail()
data.train = data.raw %>% head(2341) #2016~2019-2: trainset
data.test = data.raw %>% tail(222) #2020-1: testset
data.test$success.fail %>% table() #2020-1: success 168, fail 54

#2. Summarize Data & Cleaning Data ----

#A. Training data: 2016-1 ~ 2020-1 ----
dim(data.train) #dim: 2563, 11
data.train %>% glimpse()

#rank and mileage features might be redundant; check correlation

gg1 = ggplot(data.train, aes(x= year, y= took.cred_total.cred, group = year)) + 
  geom_boxplot()+
  ggtitle("Relationship between 'year' and 'took.cred_total.cred'") +
  xlim( "1" ,"2","3", "4","5") + 
  theme_minimal()

gg1

saveRDS(gg1, "progcons_eda1.rds")

gg2 = ggplot(data.train, aes(x= year, y= took.cred_total.cred, group = year, col = success.fail)) + 
  geom_jitter()+
  ggtitle("Relationship between 'year' and 'took.cred_total.cred'") +
  xlim( "1" ,"2","3", "4","5") + 
  theme_minimal() + 
  scale_color_manual(values = c("black", "red"))

gg2

saveRDS(gg2, "progcons_eda2.rds")

#took.cred_total.cred & year features might be redundant; check correlation

gg1 = ggplot(data.train, aes(x= year, y= took.cred_total.cred, group = year)) + 
  geom_boxplot()+
  ggtitle("Relationship between 'year' and 'took.cred_total.cred'") +
  xlim( "1" ,"2","3", "4","5") + 
  theme_minimal()

gg1

saveRDS(gg1, "progcons_eda1.rds")

gg2 = ggplot(data.train, aes(x= year, y= took.cred_total.cred, group = year, col = success.fail)) + 
  geom_jitter()+
  ggtitle("Relationship between 'year' and 'took.cred_total.cred'") +
  xlim( "1" ,"2","3", "4","5") + 
  theme_minimal() + 
  scale_color_manual(values = c("black", "red"))

gg2

saveRDS(gg2, "progcons_eda2.rds")

str(data.train) #select(-c(rank, major, app.grad, X, year))
sapply(data.train,class) #change XO to ordered factor
##2.1 Subset data
data.train = data.train %>% select(-c( ï..rank, major, app.grad, X, year))
##2.2 Change data type of target data
data.train %<>%
  mutate(`success.fail`=
           replace(`success.fail`, `success.fail` == "O", "success")) #성공

data.train %<>%
  mutate(`success.fail`=
           replace(`success.fail`, `success.fail`== "X", "fail")) #실패

data.train$success.fail %<>% as.factor %>% ordered()
data.train$success.fail %>% class
##2.3 Check changed data type
data.train %>% glimpse()
data.train %>% sapply(., class)
data.train$first.take %<>% as.factor %>% ordered()
##2.4 Descriptive Statistics
summary(data.train) # data ok, first.take: N 107, Y 2235, success.fail: f 693, s 1648
data.train %>% Hmisc::hist.data.frame()
##2.5 final check, finalize training dataset
data.train %>% sapply(., class)

train = data.train

#B. Testing data: 2020-2 ----
dim(data.test) #dim: 222, 11
data.test %>% glimpse()
str(data.test)
##2.1 Subset data
data.test = data.test %>% select(-c( ï..rank, major, app.grad, X, year))
##2.2 Change data type of target data
data.test %<>%
  mutate(`success.fail`=
           replace(`success.fail`, `success.fail` == "O", "success")) #성공

data.test %<>%
  mutate(`success.fail`=
           replace(`success.fail`, `success.fail`== "X", "fail")) #실패

data.test$success.fail %<>% as.factor %>% ordered()
data.test$success.fail %>% class
##2.3 Check changed data type
data.test %>% glimpse()
data.test %>% sapply(., class)
data.test$first.take %<>% as.factor %>% ordered()
##2.4 Descriptive Statistics
summary(data.test) # data ok, first.take: N 5, Y 217, success.fail: f 54, s 168
data.test %>% Hmisc::hist.data.frame() #mostly num.courses, year = 2

##2.5 final check, compare with training data, finalize datatest
data.test %>% sapply(., class)
str(train)
str(data.test) #same data type/ levels
test = data.test

rm(data.raw)

##2.7 Feature Extraction
#feature extract
target.label = "success.fail"

features.label = train %>% 
  select(-target.label) %>% 
  names() %T>% print

features = train %>% 
  select(features.label)

formula = features %>%
  names() %>% 
  paste(., collapse = " + ") %>% 
  paste(target.label, "~ ", .) %>% 
  as.formula(env = .GlobalEnv) %T>% print

formula

#3. Evaluate between different Algorithms ----
##3.1 Test Harness
trainControl = trainControl(method = "repeatedcv", 
                            number = 9, 
                            repeats = 3,
                            classProbs = T,
                            search = "random")
metric = "Accuracy"
##3.2 Build Models
seed = 323
##3.2.1 simple linear vs simple non-linear
#lda
set.seed(seed)
fit.lda = train(formula, 
                data = train, 
                method = "lda", 
                metric = metric, trControl = trainControl,
                preProc = c("scale", "center"))
#cart (decision tree)
set.seed(seed)
fit.cart = train(formula, 
                 data = train, 
                 method = "rpart", 
                 metric = metric, 
                 trControl = trainControl,
                 preProc = c("scale", "center"))
#knn
set.seed(seed)
fit.knn = train(formula, 
                data = train, 
                method = "knn", 
                metric = metric, 
                trControl = trainControl,
                preProc = c("scale", "center"))
# invalid: warnings of too many ties - > see in Kappa
##3.2.2 complex non-linear
#svm
set.seed(seed)
fit.svm = train(formula, 
                data = train, 
                method = "svmRadial", 
                metric = metric, 
                trControl = trainControl,
                preProc = c("scale", "center"))
#random forest
set.seed(seed)
fit.rf = train(formula, 
               data = train, 
               method = "rf", 
               metric = metric, 
               trControl = trainControl,
               preProc = c("scale", "center"))

#4. Select Best Algorithm ----
##4.1 Summarize accuracy of models
results = resamples(list(lda = fit.lda, cart = fit.cart, knn = fit.knn, svm = fit.svm, rf = fit.rf))
summary(results) #highest accuracy in rf, kappa median/mean > 0.57
dot.plot=dotplot(results) %T>% print()#CI of 95%

saveRDS(dot.plot, "algocomparisons_progcons.rds")

##4.2 Best Algorithm: random forest
print(fit.rf)
#best fit at mtry(number of vars randomly sampled) = 3

#5. Making Predictions by tuning algorithms----
#A. Random Forest: not-tuned ----
predictions = predict(fit.rf,test)
#5.A.1 Checking confusion matrix: fit.rf
confusionMatrix(predictions, test$success.fail)

#B. Random Forest: tuned ----
set.seed(seed)
fit.rf.1 = train(formula, 
                 data = train, 
                 method = "rf", 
                 metric = metric, 
                 preProc = c("scale", "center"), 
                 tunelength = 15,
                 trControl = trainControl)

pr.1 = predict(fit.rf.1, test)
#5.B.1 Checking confusion matrix: fit.rf.1
cm.rf = confusionMatrix(pr.1,test$success.fail) %T>% print
#5.B.2 Compare bewtween not-tuned rf vs tuned rf
results.rf = resamples(list(rf.nottuned= fit.rf, rf.tuned = fit.rf.1))
summary(results.rf) #highest accuracy in rf, kappa median/mean > 0.57
dot.plot1=dotplot(results.rf) %T>% print
saveRDS(dot.plot1, "rfcomparisons_progcons.rds")
#(CI of 95%) rf.tuned is better; higher accuracy, kappa
#5.B.3 Plotting Confusion Matrix for tuned rf
cm.rf.df = as.data.frame(cm.rf$table)
cm.rf.df_prop = as.data.frame(prop.table(cm.rf$table))
cm.rf.df$Perc = round(cm.rf.df_prop$Freq*100,0)
cm.rf_p = ggplot(data = cm.rf.df, aes(x = Prediction , y =  Reference, fill = Freq))+
  geom_tile() +
  geom_text(aes(label = paste("",Freq,"(",Perc,"%)")), color = 'black', size = 5) +
  theme_classic() +
  guides(fill=FALSE) +
  ggtitle("Random Forest (tuned) Confusion Matrix: 2020-1") +
  scale_fill_gradient(low = "white", high = "#badb33") +
  geom_tile(color = "black", fill = "black", alpha = 0)

cm.rf_p

#5.3 Saving confusion matrix plot: fit.rf.1
saveRDS(cm.rf_p, "randomforestcm_progcons.rds")

#C. SVM: not-tuned & tuned----
#not-tuned
predictions.svm = predict(fit.svm, test)
confusionMatrix(predictions.svm, test$success.fail)

##7.1 Tuning Parameters
library(e1071)

#7.1.1 Tuning Kernels
set.seed(seed)
result1 = tune.svm(formula, data = train, scale = F, gamma = 2^(-5:0), cost = 2^(0:4), kernel = "radial")
set.seed(seed)
result2 = tune.svm(formula, data = train, cost = 2^(0:4), kernel = "linear")
set.seed(seed)
result3 = tune.svm(formula, data = train, cost = 2^(0:4), degree = 2:4, kernel = "polynomial")
set.seed(seed)
result4 = tune.svm(formula, data = train, gamma = 2^(-5:0), cost = 2^(0:4), kernel = "sigmoid")

#7.1.2 Finding Best Params
result1$best.parameters
result2$best.parameters
result3$best.parameters
result4$best.parameters

set.seed(seed)
fit.svm.1=svm(formula, data = train, scale = F, gamma = 0.03125 , cost =16, kernel = "radial", trControl = trainControl)
set.seed(seed)
fit.svm.2=svm(formula, data = train, cost = 1, kernel = "linear", trControl = trainControl)
set.seed(seed)
fit.svm.3=svm(formula, data = train, cost = 16, degree = 4, kernel = "polynomial", trControl = trainControl)
set.seed(seed)
fit.svm.4=svm(formula, data = train, gamma = 0.03125, cost = 1, kernel = "sigmoid", trControl = trainControl)

#7.1.3 Compare five models of svm
#7.1.3 Predicting Accuracy
svm1_p = predict(fit.svm.1, test) 
# svm1_p %>% table
svm2_p = predict(fit.svm.2, test) 
# svm2_p %>% table
svm3_p = predict(fit.svm.3, test) 
# svm3_p %>% table
svm4_p = predict(fit.svm.4, test)
# svm4_p %>% table()
confusionMatrix(svm1_p, test$success.fail) #best svm- Accuracy : 0.8198,  Kappa : 0.6009 
confusionMatrix(svm2_p, test$success.fail) 
confusionMatrix(svm3_p, test$success.fail) 
confusionMatrix(svm4_p, test$success.fail)
#7.1.4 Plotting Confusion Matrix for best svm
cm.svm = confusionMatrix(svm1_p, test$success.fail)
cm.svm.df = as.data.frame(cm.svm$table)
cm.svm.df_prop = as.data.frame(prop.table(cm.svm$table))
cm.svm.df$Perc = round(cm.svm.df_prop$Freq*100,0)
cm.svm_p = ggplot(data = cm.svm.df, aes(x = Prediction , y =  Reference, fill = Freq))+
  geom_tile() +
  geom_text(aes(label = paste("",Freq,"(",Perc,"%)")), color = 'black', size = 5) +
  theme_classic() +
  guides(fill=FALSE) +
  ggtitle("Support Vector Machine (tuned) Confusion Matrix: 2020-1") +
  scale_fill_gradient(low = "white", high = "#badb33") +
  geom_tile(color = "black", fill = "black", alpha = 0)

cm.svm_p
saveRDS(cm.svm_p, "svmcm_progcons.rds")

#8.Compare best models: fit.rf.1 vs fit.svm.1
# rm(list=ls())
# dev.off()
readRDS("randomforestcm_progcons.rds") #fit.rf.1
readRDS("svmcm_progcons.rds") #fit.svm.1
# best model = fit.rf.1 (tuned random forest)
